const { ActivityType } = require('discord.js');
const config = require('../config.json');

module.exports = {
  name: 'ready',
  once: true,
  execute(client) {
    console.log('Bot giriş yaptı!');

    // Config'den durum bilgilerini al
    const { type, name, status } = config.status;
    const activityType = {
      PLAYING: ActivityType.Playing,
      STREAMING: ActivityType.Streaming,
      LISTENING: ActivityType.Listening,
      WATCHING: ActivityType.Watching
    }[type.toUpperCase()] || ActivityType.Playing; // Varsayılan tür PLAYING

    try {
      // Botun durumunu ayarlayın
      client.user.setPresence({
        activities: [{ name, type: activityType }],
        status: status || 'dnd' // Varsayılan durum online
      });
      console.log(`Bot durumu ayarlandı: ${name}`);
    } catch (error) {
      console.error('Bot durumu ayarlanırken bir hata oluştu:', error);
    }
  }
};
