// commands/unban.js
const { PermissionsBitField } = require('discord.js');

module.exports = {
  name: 'unban',
  description: 'Yasaklanan kullanıcıyı sunucuya geri alır.',
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.BanMembers)) {
      return message.reply('Bu komutu kullanmak için yeterli yetkiniz yok.');
    }

    const userId = args[0];
    if (!userId) {
      return message.reply('Yasağı kaldırmak için geçerli bir kullanıcı ID\'si girmelisiniz.');
    }

    try {
      await message.guild.members.unban(userId);
      message.reply(`Kullanıcı yasaktan kaldırıldı.`);
    } catch (error) {
      message.reply('Bir hata oluştu. Kullanıcı ID\'sini kontrol edin ve tekrar deneyin.');
    }
  },
};
