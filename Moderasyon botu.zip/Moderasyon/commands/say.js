// commands/say.js
module.exports = {
      name: 'say',
      description: 'Botun belirttiğiniz mesajı tekrar etmesini sağlar.',
      execute(message, args) {
        const text = args.join(' ');
        if (!text) {
          return message.reply('Tekrar etmem için bir mesaj yazmalısınız.');
        }
        message.delete(); // Kullanıcının komut mesajını siler
        message.channel.send(text);
      },
    };
    