// commands/ban.js
const { PermissionsBitField } = require('discord.js');

module.exports = {
  name: 'ban',
  description: 'Bir kullanıcıyı sunucudan yasaklar.',
  execute(message, args) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.BanMembers)) {
      return message.reply('Bu komutu kullanmak için yeterli yetkiniz yok.');
    }

    const user = message.mentions.users.first();
    if (!user) {
      return message.reply('Yasaklamak için bir kullanıcı etiketlemelisiniz.');
    }

    const member = message.guild.members.cache.get(user.id);
    if (!member) {
      return message.reply('Bu kullanıcı sunucuda bulunmuyor.');
    }

    const reason = args.slice(1).join(' ') || 'Belirtilmemiş';
    member.ban({ reason })
      .then(() => message.reply(`${user.tag} yasaklandı. Sebep: ${reason}`))
      .catch(error => message.reply('Bir hata oluştu.'));
  },
};
