// commands/help.js
const { EmbedBuilder } = require('discord.js');
const config = require('../config.json');

module.exports = {
  name: 'help',
  description: 'Botun tüm komutlarını listeler.',
  execute(message) {
    const prefix = config.prefix;

    const helpEmbed = new EmbedBuilder()
      .setTitle('Yardım Menüsü')
      .setColor('#3498db')
      .setDescription('Aşağıda botun mevcut komutlarını bulabilirsiniz.')
      .addFields(
        { name: 'Moderasyon Komutları', value: `\`${prefix}ban\`, \`${prefix}kick\`, \`${prefix}mute\`, \`${prefix}unmute\`, \`${prefix}warn\`, \`${prefix}unwarn\`, \`${prefix}clear\`, \`${prefix}lock\`, \`${prefix}unlock\`, \`${prefix}slowmode\`` },
        { name: 'Bilgi Komutları', value: `\`${prefix}serverinfo\`, \`${prefix}roleinfo\`, \`${prefix}userinfo\`, \`${prefix}botinfo\`` },
        { name: 'Diğer Komutlar', value: `\`${prefix}say\`, \`${prefix}announce\`, \`${prefix}help\`` }
      )
      .setFooter({ text: `Daha fazla bilgi için belirli bir komut adıyla "${prefix}help <komut>" yazabilirsiniz.` });

    message.channel.send({ embeds: [helpEmbed] });
  },
};
