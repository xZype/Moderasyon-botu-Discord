// commands/unmute.js
const { PermissionsBitField } = require('discord.js');

module.exports = {
  name: 'unmute',
  description: 'Susturulan kullanıcının susturmasını kaldırır.',
  execute(message, args) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
      return message.reply('Bu komutu kullanmak için yeterli yetkiniz yok.');
    }

    const user = message.mentions.users.first();
    if (!user) {
      return message.reply('Susturmasını kaldırmak için bir kullanıcı etiketlemelisiniz.');
    }

    const member = message.guild.members.cache.get(user.id);
    if (!member) {
      return message.reply('Bu kullanıcı sunucuda bulunmuyor.');
    }

    member.timeout(null)
      .then(() => message.reply(`${user.tag} susturulması kaldırıldı.`))
      .catch(error => message.reply('Bir hata oluştu.'));
  },
};
