// commands/mute.js
const { PermissionsBitField } = require('discord.js');

module.exports = {
  name: 'mute',
  description: 'Bir kullanıcıyı belirli bir süre susturur.',
  execute(message, args) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
      return message.reply('Bu komutu kullanmak için yeterli yetkiniz yok.');
    }

    const user = message.mentions.users.first();
    if (!user) {
      return message.reply('Susturmak için bir kullanıcı etiketlemelisiniz.');
    }

    const member = message.guild.members.cache.get(user.id);
    if (!member) {
      return message.reply('Bu kullanıcı sunucuda bulunmuyor.');
    }

    const time = parseInt(args[1], 10);
    if (!time || isNaN(time)) {
      return message.reply('Geçerli bir süre belirtmelisiniz.');
    }

    const reason = args.slice(2).join(' ') || 'Belirtilmemiş';
    member.timeout(time * 60 * 1000, reason)
      .then(() => message.reply(`${user.tag} ${time} dakika boyunca susturuldu. Sebep: ${reason}`))
      .catch(error => message.reply('Bir hata oluştu.'));
  },
};
