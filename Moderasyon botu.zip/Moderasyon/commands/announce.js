// commands/announce.js
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'announce',
  description: 'Belirtilen mesajı duyuru olarak gönderir.',
  execute(message, args) {
    const announcement = args.join(' ');
    if (!announcement) {
      return message.reply('Duyurmak için bir mesaj belirtmelisiniz.');
    }

    const announceEmbed = new EmbedBuilder()
      .setTitle('📢 Duyuru')
      .setColor('#e74c3c')
      .setDescription(announcement)
      .setFooter({ text: `Duyuru yapan: ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
      .setTimestamp();

    message.channel.send({ embeds: [announceEmbed] });
  },
};
