// commands/warnings.js
const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'warnings',
  description: 'Kullanıcının aldığı uyarıları listeler.',
  execute(message, args) {
    const user = message.mentions.users.first();
    if (!user) {
      return message.reply('Uyarılarını görmek için bir kullanıcı etiketlemelisiniz.');
    }

    const warnsPath = path.join(__dirname, '../data/warns.json');
    if (!fs.existsSync(warnsPath)) {
      return message.reply('Bu kullanıcıya ait uyarı bulunmamaktadır.');
    }

    const warns = JSON.parse(fs.readFileSync(warnsPath, 'utf8'));

    if (!warns[user.id] || warns[user.id].length === 0) {
      return message.reply('Bu kullanıcıya ait uyarı bulunmamaktadır.');
    }

    const warningList = warns[user.id]
      .map((warn, index) => `${index + 1}. Sebep: ${warn.reason}, Tarih: ${warn.date}`)
      .join('\n');

    message.reply(`\`${user.tag}\` kullanıcısının uyarıları:\n${warningList}`);
  },
};
