// commands/userinfo.js
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'userinfo',
  description: 'Belirtilen kullanıcı hakkında bilgi verir.',
  execute(message, args) {
    const user = message.mentions.users.first() || message.author;
    const member = message.guild.members.cache.get(user.id);

    const userInfoEmbed = new EmbedBuilder()
      .setTitle(`${user.username} Kullanıcı Bilgisi`)
      .setColor('#2ecc71')
      .setThumbnail(user.displayAvatarURL())
      .addFields(
        { name: 'Kullanıcı İsmi', value: user.tag, inline: true },
        { name: 'Kullanıcı ID', value: user.id, inline: true },
        { name: 'Sunucuya Katılma Tarihi', value: member.joinedAt.toDateString(), inline: true },
        { name: 'Hesap Oluşturulma Tarihi', value: user.createdAt.toDateString(), inline: true },
        { name: 'Roller', value: member.roles.cache.map(role => role.name).join(', '), inline: true }
      );

    message.channel.send({ embeds: [userInfoEmbed] });
  },
};
