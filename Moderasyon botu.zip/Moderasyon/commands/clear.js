// commands/clear.js
module.exports = {
      name: 'clear',
      description: 'Belirtilen sayıda mesajı siler.',
      async execute(message, args) {
        if (!message.member.permissions.has('MANAGE_MESSAGES')) {
          return message.reply('Bu komutu kullanmak için yeterli yetkiniz yok.');
        }
    
        const deleteCount = parseInt(args[0], 10);
        if (!deleteCount || deleteCount < 1 || deleteCount > 100) {
          return message.reply('Lütfen 1 ile 100 arasında bir sayı belirtin.');
        }
    
        try {
          const deletedMessages = await message.channel.bulkDelete(deleteCount, true);
          message.reply(`${deletedMessages.size} mesaj silindi.`);
        } catch (error) {
          message.reply('Mesajlar silinirken bir hata oluştu.');
        }
      },
    };
    