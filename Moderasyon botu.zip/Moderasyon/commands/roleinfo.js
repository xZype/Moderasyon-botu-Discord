// commands/roleinfo.js
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'roleinfo',
  description: 'Belirtilen rol hakkında bilgi verir.',
  execute(message, args) {
    const roleName = args.join(' ');
    if (!roleName) {
      return message.reply('Lütfen bir rol adı belirtin.');
    }

    const role = message.guild.roles.cache.find(r => r.name === roleName);
    if (!role) {
      return message.reply('Bu isimde bir rol bulunamadı.');
    }

    const roleEmbed = new EmbedBuilder()
      .setTitle('Rol Bilgisi')
      .setColor(role.color || '#000000')
      .addFields(
        { name: 'Rol İsmi', value: role.name, inline: true },
        { name: 'Rol ID', value: role.id, inline: true },
        { name: 'Renk', value: role.hexColor, inline: true },
        { name: 'Oluşturulma Tarihi', value: role.createdAt.toDateString(), inline: true },
        { name: 'Üye Sayısı', value: role.members.size.toString(), inline: true }
      );

    message.channel.send({ embeds: [roleEmbed] });
  },
};
