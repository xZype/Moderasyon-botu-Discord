// commands/unlock.js
const { PermissionsBitField } = require('discord.js');

module.exports = {
  name: 'unlock',
  description: 'Kanalın kilidini açar.',
  execute(message) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
      return message.reply('Bu komutu kullanmak için yeterli yetkiniz yok.');
    }

    message.channel.permissionOverwrites.create(message.guild.roles.everyone, {
      SendMessages: true,
    })
      .then(() => message.reply('Kanalın kilidi açıldı.'))
      .catch(error => message.reply('Bir hata oluştu.'));
  },
};
