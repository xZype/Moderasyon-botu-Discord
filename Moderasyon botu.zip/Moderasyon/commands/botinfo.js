// commands/botinfo.js
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'botinfo',
  description: 'Bot hakkında bilgi verir.',
  execute(message) {
    const botInfoEmbed = new EmbedBuilder()
      .setTitle('Bot Bilgisi')
      .setColor('#1abc9c')
      .setThumbnail(message.client.user.displayAvatarURL())
      .addFields(
        { name: 'Bot İsmi', value: message.client.user.username, inline: true },
        { name: 'Bot ID', value: message.client.user.id, inline: true },
        { name: 'Sunucu Sayısı', value: message.client.guilds.cache.size.toString(), inline: true },
        { name: 'Toplam Kullanıcı', value: message.client.users.cache.size.toString(), inline: true },
        { name: 'Oluşturulma Tarihi', value: message.client.user.createdAt.toDateString(), inline: true }
      );

    message.channel.send({ embeds: [botInfoEmbed] });
  },
};
