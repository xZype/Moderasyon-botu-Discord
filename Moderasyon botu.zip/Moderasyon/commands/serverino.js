// commands/serverinfo.js
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'serverinfo',
  description: 'Sunucu hakkında bilgi verir.',
  execute(message) {
    const { guild } = message;

    const serverInfoEmbed = new EmbedBuilder()
      .setTitle('Sunucu Bilgisi')
      .setColor('#3498db')
      .setThumbnail(guild.iconURL())
      .addFields(
        { name: 'Sunucu İsmi', value: guild.name, inline: true },
        { name: 'Sunucu ID', value: guild.id, inline: true },
        { name: 'Sunucu Sahibi', value: `<@${guild.ownerId}>`, inline: true },
        { name: 'Üye Sayısı', value: guild.memberCount.toString(), inline: true },
        { name: 'Oluşturulma Tarihi', value: guild.createdAt.toDateString(), inline: true }
      );

    message.channel.send({ embeds: [serverInfoEmbed] });
  },
};
