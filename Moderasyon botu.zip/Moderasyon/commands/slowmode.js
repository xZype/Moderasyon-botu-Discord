// commands/slowmode.js
module.exports = {
      name: 'slowmode',
      description: 'Kanalda yavaş mod ayarlar.',
      execute(message, args) {
        if (!message.member.permissions.has('MANAGE_CHANNELS')) {
          return message.reply('Bu komutu kullanmak için yeterli yetkiniz yok.');
        }
    
        const time = parseInt(args[0], 10);
        if (isNaN(time) || time < 0) {
          return message.reply('Geçerli bir süre belirtmelisiniz.');
        }
    
        message.channel.setRateLimitPerUser(time)
          .then(() => message.reply(`Yavaş mod ${time} saniye olarak ayarlandı.`))
          .catch(error => message.reply('Bir hata oluştu.'));
      },
    };
    