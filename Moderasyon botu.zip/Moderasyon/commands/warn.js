// commands/warn.js
const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'warn',
  description: 'Kullanıcıya uyarı verir.',
  execute(message, args) {
    if (!message.member.permissions.has('KICK_MEMBERS')) {
      return message.reply('Bu komutu kullanmak için yeterli yetkiniz yok.');
    }

    const user = message.mentions.users.first();
    if (!user) {
      return message.reply('Uyarı vermek için bir kullanıcı etiketlemelisiniz.');
    }

    const reason = args.slice(1).join(' ') || 'Belirtilmemiş';

    const warnsPath = path.join(__dirname, '../data/warns.json');
    if (!fs.existsSync(warnsPath)) {
      fs.writeFileSync(warnsPath, '{}', 'utf8');
    }

    const warns = JSON.parse(fs.readFileSync(warnsPath, 'utf8'));

    if (!warns[user.id]) {
      warns[user.id] = [];
    }

    warns[user.id].push({ reason, date: new Date().toISOString() });

    fs.writeFileSync(warnsPath, JSON.stringify(warns, null, 2), 'utf8');

    message.reply(`${user.tag} kullanıcısına uyarı verildi. Sebep: ${reason}`);
  },
};
